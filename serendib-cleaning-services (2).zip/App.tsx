import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import WhyUs from './components/WhyUs';
import QuoteForm from './components/QuoteForm';
import Contact from './components/Contact';
import Footer from './components/Footer';
import ServiceAreas from './components/ServiceAreas';
import PrivacyPolicy from './components/PrivacyPolicy';
import TermsOfService from './components/TermsOfService';
import { PhoneCall } from 'lucide-react';
import { CONTACT_INFO } from './constants';
import { View } from './types';

const App: React.FC = () => {
  const [showFloatBtn, setShowFloatBtn] = useState(false);
  const [currentView, setCurrentView] = useState<View>('home');

  useEffect(() => {
    const handleScroll = () => {
      setShowFloatBtn(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="relative font-sans text-slate-800">
      <Navbar currentView={currentView} onViewChange={setCurrentView} />
      
      <main>
        {currentView === 'home' && (
          <>
            <Hero />
            <Services />
            <WhyUs />
            <ServiceAreas />
            <QuoteForm />
            <Contact />
          </>
        )}
        {currentView === 'privacy' && <PrivacyPolicy />}
        {currentView === 'terms' && <TermsOfService />}
      </main>

      <Footer onViewChange={setCurrentView} />

      {/* Floating Action Button */}
      <a
        href={`tel:${CONTACT_INFO.phone.replace(/-/g, '')}`}
        className={`fixed bottom-6 right-6 z-40 bg-brand hover:bg-brand-dark text-white p-4 rounded-full shadow-2xl transition-all duration-300 transform hover:scale-110 flex items-center justify-center ${
          showFloatBtn ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'
        }`}
        aria-label="Call Now"
      >
        <PhoneCall size={24} className="animate-pulse" />
      </a>
    </div>
  );
};

export default App;