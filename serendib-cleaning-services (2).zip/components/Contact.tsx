import React from 'react';
import { MapPin, Phone, Mail, Clock, ArrowRight } from 'lucide-react';
import { CONTACT_INFO } from '../constants';

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center mb-16">
            <h2 className="text-4xl font-black text-brand-black mb-4">Get in Touch</h2>
            <div className="w-20 h-1.5 bg-brand mx-auto rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Contact Details Card */}
          <div className="lg:col-span-1 bg-brand-black text-white p-10 rounded-3xl shadow-2xl relative overflow-hidden">
            {/* Abstract Circle */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-brand rounded-full blur-3xl opacity-20"></div>

            <div className="relative z-10 space-y-10">
              <div className="flex items-start gap-5">
                <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-brand shrink-0">
                  <MapPin size={24} />
                </div>
                <div>
                  <p className="text-gray-200 font-medium leading-relaxed mb-3 text-lg">
                    3205 Vincent Massey Drive<br />
                    Long Sault, ON K0C 1P0
                  </p>
                  <a href={CONTACT_INFO.mapsLink} target="_blank" rel="noopener noreferrer" className="text-brand text-xs font-bold uppercase tracking-wide hover:text-white transition-colors flex items-center gap-1">
                    Get Directions <ArrowRight size={12} />
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-5">
                <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-brand shrink-0">
                  <Phone size={24} />
                </div>
                <div>
                  <p className="text-gray-400 text-sm mb-1">Available 24/7</p>
                  <a href={`tel:${CONTACT_INFO.phone.replace(/-/g, '')}`} className="text-xl font-bold text-white hover:text-brand transition-colors">
                    {CONTACT_INFO.phone}
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-5">
                <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-brand shrink-0">
                  <Mail size={24} />
                </div>
                <div>
                  <a href={`mailto:${CONTACT_INFO.email}`} className="text-gray-200 font-medium hover:text-brand transition-colors text-lg break-all">
                    {CONTACT_INFO.email}
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Map */}
          <div className="lg:col-span-2 min-h-[400px] rounded-3xl overflow-hidden shadow-lg border border-gray-100 relative group">
             <div className="absolute inset-0 bg-brand/10 z-10 pointer-events-none group-hover:bg-transparent transition-colors duration-500"></div>
             <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2817.234!2d-74.9765!3d45.0054!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4cccb8c8c8c8c8c8%3A0x1234567890abcdef!2s3205%20Vincent%20Massey%20Dr%2C%20Long%20Sault%2C%20ON%20K0C%201P0!5e0!3m2!1sen!2sca!4v1234567890123" 
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen={true} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
                title="Serendib Location"
                className="w-full h-full grayscale group-hover:grayscale-0 transition-all duration-700"
            ></iframe>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Contact;