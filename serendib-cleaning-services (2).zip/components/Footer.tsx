import React from 'react';
import { ArrowUp, Instagram, Facebook, Linkedin } from 'lucide-react';
import { View } from '../types';

interface FooterProps {
    onViewChange: (view: View) => void;
}

const Footer: React.FC<FooterProps> = ({ onViewChange }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetId = href.replace('#', '');
    
    if (targetId === 'home' || targetId === 'services' || targetId === 'why-us' || targetId === 'contact') {
        onViewChange('home');
        setTimeout(() => {
            const element = document.getElementById(targetId);
            if (element) {
                element.scrollIntoView({ behavior: 'smooth' });
            } else {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        }, 100);
    }
  };

  const handleLegalClick = (e: React.MouseEvent<HTMLAnchorElement>, view: View) => {
      e.preventDefault();
      onViewChange(view);
  };

  return (
    <footer className="bg-black text-white pt-24 pb-12 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          
          {/* Brand */}
          <div className="md:col-span-2 space-y-6">
            <h3 className="text-2xl font-black tracking-tight flex items-center gap-2">
                SERENDIB CLEANING SERVICES
            </h3>
            <p className="text-gray-400 text-sm leading-relaxed max-w-sm">
              Professional commercial cleaning services setting the standard in Eastern Ontario. We are committed to excellence, reliability, and creating healthy environments for your business.
            </p>
            <div className="flex gap-4">
                <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-brand transition-colors text-white">
                    <Facebook size={18} />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-brand transition-colors text-white">
                    <Instagram size={18} />
                </a>
                <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-brand transition-colors text-white">
                    <Linkedin size={18} />
                </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-bold text-lg mb-6 text-white">Navigation</h4>
            <ul className="space-y-4 text-gray-400 text-sm font-medium">
              <li><a href="#home" onClick={(e) => handleLinkClick(e, '#home')} className="hover:text-brand transition-colors">Home</a></li>
              <li><a href="#services" onClick={(e) => handleLinkClick(e, '#services')} className="hover:text-brand transition-colors">Services</a></li>
              <li><a href="#why-us" onClick={(e) => handleLinkClick(e, '#why-us')} className="hover:text-brand transition-colors">Why Us</a></li>
              <li><a href="#contact" onClick={(e) => handleLinkClick(e, '#contact')} className="hover:text-brand transition-colors">Contact</a></li>
            </ul>
          </div>
          
           {/* Legal/Other */}
           <div>
            <h4 className="font-bold text-lg mb-6 text-white">Legal</h4>
            <ul className="space-y-4 text-gray-400 text-sm font-medium">
              <li><a href="#" onClick={(e) => handleLegalClick(e, 'privacy')} className="hover:text-brand transition-colors">Privacy Policy</a></li>
              <li><a href="#" onClick={(e) => handleLegalClick(e, 'terms')} className="hover:text-brand transition-colors">Terms of Service</a></li>
            </ul>
          </div>

        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-gray-600 text-sm">
            &copy; {new Date().getFullYear()} Serendib Cleaning Services. All rights reserved.
          </p>
          
          <button 
            onClick={scrollToTop}
            className="p-3 bg-white/5 rounded-full hover:bg-brand transition-colors group border border-white/5"
            aria-label="Scroll to top"
          >
            <ArrowUp size={20} className="text-gray-400 group-hover:text-white" />
          </button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;