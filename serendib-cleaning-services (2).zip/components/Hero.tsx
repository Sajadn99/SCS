import React from 'react';
import { ArrowRight, CheckCircle, Shield } from 'lucide-react';

export default function Hero() {
  const handleScroll = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetId = href.replace('#', '');
    const element = document.getElementById(targetId);
    if (element) {
      const headerOffset = 100;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <section id="home" className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden bg-slate-900">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=2301" 
          alt="Clean modern office space" 
          className="w-full h-full object-cover opacity-30"
        />
        {/* Gradient Overlay - Rich Emerald to Black */}
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-brand-dark/90 to-slate-900/80"></div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        {/* Single column layout since image was removed */}
        <div className="max-w-3xl">
          <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black text-white leading-tight mb-6 tracking-tight drop-shadow-lg">
            Cleaning That <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-light to-brand">Inspires Success.</span>
          </h1>
          
          <p className="text-lg text-gray-300 mb-8 leading-relaxed max-w-xl font-light">
            Elevate your business environment with Eastern Ontario's most reliable cleaning team. We combine the highest hygiene standards with eco-friendly practices.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-5">
            <a 
              href="#quote" 
              onClick={(e) => handleScroll(e, '#quote')}
              className="group relative inline-flex items-center justify-center px-8 py-4 text-base font-bold text-white bg-brand rounded-full overflow-hidden transition-all duration-300 shadow-[0_0_20px_rgba(16,185,129,0.4)] hover:shadow-[0_0_30px_rgba(16,185,129,0.6)] hover:-translate-y-1"
            >
              <span className="relative flex items-center gap-2">
                Get Free Quote
                <ArrowRight size={20} className="transition-transform group-hover:translate-x-1" />
              </span>
            </a>
            <a 
              href="#services" 
              onClick={(e) => handleScroll(e, '#services')}
              className="inline-flex items-center justify-center px-8 py-4 text-base font-bold text-white border border-white/20 bg-white/5 backdrop-blur-sm rounded-full hover:bg-white/10 hover:border-white/40 transition-all duration-300"
            >
              Explore Services
            </a>
          </div>

          <div className="mt-12 flex flex-wrap gap-6 text-sm font-semibold text-gray-400">
             <div className="flex items-center gap-2">
                <Shield className="text-brand" size={18} />
                <span>Bonded & Insured</span>
             </div>
             <div className="flex items-center gap-2">
                <CheckCircle className="text-brand" size={18} />
                <span>Satisfaction Guaranteed</span>
             </div>
          </div>
        </div>
      </div>
    </section>
  );
}