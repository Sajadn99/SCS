import React, { useState, useEffect } from 'react';
import { Menu, X, Phone, Mail, Droplets } from 'lucide-react';
import { CONTACT_INFO } from '../constants';
import { View } from '../types';

const Logo = () => (
  <div className="flex items-center gap-3">
    <div className="relative flex items-center justify-center w-10 h-10 md:w-11 md:h-11 bg-gradient-to-br from-brand-light to-brand-dark rounded-xl shadow-lg shadow-brand/20">
      <Droplets className="w-5 h-5 md:w-6 md:h-6 text-white" strokeWidth={2.5} />
    </div>
    <div className="flex flex-col">
      <span className="text-lg md:text-xl font-black text-slate-800 leading-none tracking-tight uppercase">Serendib</span>
      <span className="text-[9px] md:text-[10px] font-bold text-brand uppercase tracking-[0.2em] leading-tight mt-1">Cleaning Services</span>
    </div>
  </div>
);

interface NavbarProps {
  currentView: View;
  onViewChange: (view: View) => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentView, onViewChange }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToElement = (targetId: string) => {
    const element = document.getElementById(targetId);
    if (element) {
      const headerOffset = 100;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    } else {
        // Fallback if element not found immediately (rare race condition)
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setIsOpen(false);
    const targetId = href.replace('#', '');

    if (currentView !== 'home') {
        onViewChange('home');
        // Wait for state update and render
        setTimeout(() => {
            scrollToElement(targetId);
        }, 100);
    } else {
        scrollToElement(targetId);
    }
  };

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Services', href: '#services' },
    { name: 'Why Us', href: '#why-us' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <>
      <nav 
        className={`fixed w-full z-50 transition-all duration-300 border-b border-gray-100 ${
          isScrolled 
            ? 'bg-white/95 backdrop-blur-md py-2 shadow-md' 
            : 'bg-white py-3 shadow-sm'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            
            {/* Logo Section */}
            <a 
              href="#home" 
              onClick={(e) => handleNavClick(e, '#home')}
              className="flex items-center group transition-transform duration-300 hover:scale-105"
            >
              <Logo />
            </a>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center space-x-1">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className="px-4 py-2 text-sm font-bold text-slate-600 hover:text-brand transition-colors rounded-full hover:bg-brand-light/10 uppercase tracking-wide"
                >
                  {link.name}
                </a>
              ))}
              
              <div className="pl-4 ml-4 border-l border-gray-200">
                <a
                  href={`tel:${CONTACT_INFO.phone.replace(/-/g, '')}`}
                  className="flex items-center gap-2 px-6 py-2.5 bg-brand hover:bg-brand-dark text-white rounded-full font-bold text-sm transition-all shadow-lg shadow-brand/30 hover:shadow-brand/50 transform hover:-translate-y-0.5 whitespace-nowrap"
                >
                  <Phone size={16} />
                  <span>Schedule Consultation</span>
                </a>
              </div>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden flex items-center gap-4">
              <a
                  href={`tel:${CONTACT_INFO.phone.replace(/-/g, '')}`}
                  className="flex items-center justify-center w-10 h-10 bg-brand text-white rounded-full shadow-lg"
                  aria-label="Call Now"
                >
                  <Phone size={18} />
              </a>
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="p-2 text-slate-800 hover:bg-gray-100 rounded-lg transition-colors"
                aria-label="Toggle menu"
              >
                {isOpen ? <X size={28} /> : <Menu size={28} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu Overlay */}
        <div 
          className={`md:hidden absolute top-full left-0 w-full bg-white border-t border-gray-100 shadow-xl transition-all duration-300 ease-in-out origin-top ${
            isOpen ? 'scale-y-100 opacity-100' : 'scale-y-0 opacity-0'
          }`}
        >
          <div className="px-6 py-6 space-y-2 flex flex-col bg-white">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="text-slate-800 hover:text-brand hover:bg-brand-light/10 font-bold text-lg px-4 py-3 rounded-xl transition-colors"
              >
                {link.name}
              </a>
            ))}
            
            <div className="mt-4 pt-4 border-t border-gray-100 grid grid-cols-2 gap-4">
                 <a href={`mailto:${CONTACT_INFO.email}`} className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-xl hover:bg-brand-light/10 transition-colors">
                    <Mail className="text-brand mb-2" size={20} />
                    <span className="text-xs font-bold text-slate-600">Email</span>
                 </a>
                 <a href={`tel:${CONTACT_INFO.phone.replace(/-/g, '')}`} className="flex flex-col items-center justify-center p-4 bg-gray-50 rounded-xl hover:bg-brand-light/10 transition-colors">
                    <Phone className="text-brand mb-2" size={20} />
                    <span className="text-xs font-bold text-slate-600">Call Us</span>
                 </a>
            </div>
          </div>
        </div>
      </nav>
    </>
  );
};

export default Navbar;