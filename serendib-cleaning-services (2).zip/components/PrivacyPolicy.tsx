import React, { useEffect } from 'react';

const PrivacyPolicy: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <section className="pt-32 pb-24 px-4 sm:px-6 lg:px-8 bg-slate-50 min-h-screen">
      <div className="max-w-4xl mx-auto bg-white p-8 md:p-12 rounded-3xl shadow-sm border border-gray-100">
        <h1 className="text-3xl md:text-4xl font-black text-slate-900 mb-8">Privacy Policy</h1>
        
        <div className="prose prose-slate max-w-none text-slate-600">
          <p className="mb-6">Last updated: {new Date().toLocaleDateString()}</p>

          <p className="mb-6">
            At Serendib Cleaning Services ("we," "our," or "us"), we respect your privacy and are committed to protecting the personal information you share with us. This Privacy Policy explains how we collect, use, and safeguard your information when you visit our website or use our services.
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">1. Information We Collect</h2>
          <p className="mb-4">
            We collect information that you voluntarily provide to us, primarily through our "Get Free Quote" and "Contact" forms. This includes:
          </p>
          <ul className="list-disc pl-5 mb-6 space-y-2">
            <li>Personal identification (Name, Email Address, Phone Number)</li>
            <li>Business details (Company Name, Address)</li>
            <li>Service requirements and preferences</li>
            <li>Any other information you choose to provide in your messages to us</li>
          </ul>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">2. How We Use Your Information</h2>
          <p className="mb-4">
            We use the information we collect for the following purposes:
          </p>
          <ul className="list-disc pl-5 mb-6 space-y-2">
            <li>To provide, operate, and maintain our services</li>
            <li>To generate and send accurate service quotes</li>
            <li>To communicate with you regarding your inquiries or scheduled services</li>
            <li>To improve our website user experience and customer service</li>
          </ul>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">3. Information Sharing</h2>
          <p className="mb-6">
            We do not sell, trade, or rent your personal identification information to others. We may share generic aggregated demographic information not linked to any personal identification information regarding visitors and users with our business partners for the purposes outlined above.
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">4. Data Security</h2>
          <p className="mb-6">
            We adopt appropriate data collection, storage, and processing practices and security measures to protect against unauthorized access, alteration, disclosure, or destruction of your personal information.
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">5. Contact Us</h2>
          <p className="mb-6">
            If you have any questions about this Privacy Policy, please contact us at:
            <br />
            <strong>Email:</strong> contact@serendibcleaningservices.ca
            <br />
            <strong>Phone:</strong> 613-861-5196
          </p>
        </div>
      </div>
    </section>
  );
};

export default PrivacyPolicy;