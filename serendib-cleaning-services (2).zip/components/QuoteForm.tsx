import React, { useState } from 'react';
import { Send, Loader2, CheckCircle, Check, ArrowRight, ShieldCheck } from 'lucide-react';
import { QuoteFormData } from '../types';

const SERVICE_CATEGORIES = [
  {
    category: "General",
    items: ["Janitorial Services", "General Cleaning", "Restroom Deep Clean", "Sanitization"]
  },
  {
    category: "Floor Care",
    items: ["Floor Strip & Wax", "Carpet Cleaning", "Tile & Grout", "Buffing & Polishing"]
  },
  {
    category: "Specialty",
    items: ["Window Cleaning", "Post-Construction", "Power Washing", "High Dusting"]
  }
];

const FREQUENCY_OPTIONS = ["One Time", "Weekly", "Bi-Weekly", "Monthly"];

const QuoteForm: React.FC = () => {
  const [formData, setFormData] = useState<QuoteFormData>({
    name: '',
    business: '',
    email: '',
    phone: '',
    services: [],
    frequency: '',
    message: ''
  });

  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const toggleService = (service: string) => {
    setFormData(prev => {
      const exists = prev.services.includes(service);
      if (exists) {
        return { ...prev, services: prev.services.filter(s => s !== service) };
      } else {
        return { ...prev, services: [...prev.services, service] };
      }
    });
  };

  const setFrequency = (frequency: string) => {
     setFormData(prev => ({ ...prev, frequency }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    
    // Simulate API call
    setTimeout(() => {
      setStatus('success');
      // Reset form after 3 seconds
      setFormData({
        name: '', business: '', email: '', phone: '', services: [], frequency: '', message: ''
      });
    }, 1500);
  };

  return (
    <section id="quote" className="py-24 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="bg-slate-50 rounded-[2rem] shadow-xl overflow-hidden border border-gray-100">
          <div className="flex flex-col lg:flex-row">
            
            {/* Left Panel - Brand Color */}
            <div className="lg:w-2/5 bg-brand p-12 lg:p-16 text-white flex flex-col justify-center relative overflow-hidden">
               <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
               <div className="absolute bottom-0 left-0 w-64 h-64 bg-black/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>
               
               <div className="relative z-10">
                 <h2 className="text-3xl font-black mb-6">Let's Clean Up.</h2>
                 <p className="text-brand-light mb-10 text-lg font-medium leading-relaxed">
                   Get a customized cleaning plan that fits your budget and schedule. No hidden fees, just spotless results.
                 </p>
                 
                 <div className="space-y-6">
                   <div className="flex items-center gap-4 group">
                     <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center shrink-0 group-hover:bg-white/30 transition-colors">
                        <Check size={24} className="text-white" />
                     </div>
                     <span className="font-bold text-lg">Fast & Free Quotes</span>
                   </div>
                   <div className="flex items-center gap-4 group">
                     <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center shrink-0 group-hover:bg-white/30 transition-colors">
                        <Check size={24} className="text-white" />
                     </div>
                     <span className="font-bold text-lg">Custom Cleaning Plans</span>
                   </div>
                   <div className="flex items-center gap-4 group">
                     <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center shrink-0 group-hover:bg-white/30 transition-colors">
                        <ShieldCheck size={24} className="text-white" />
                     </div>
                     <div className="flex flex-col">
                        <span className="font-bold text-lg">No Hidden Fees</span>
                        <span className="text-sm text-brand-light/90 font-medium">Transparent, upfront pricing</span>
                     </div>
                   </div>
                 </div>
               </div>
            </div>

            {/* Right Panel - Form */}
            <div className="lg:w-3/5 p-8 lg:p-16 bg-white">
              {status === 'success' ? (
                <div className="h-full flex flex-col items-center justify-center py-12 text-center animate-fade-in">
                  <div className="w-20 h-20 bg-brand/10 text-brand rounded-full flex items-center justify-center mb-6">
                    <CheckCircle size={40} />
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Request Received!</h3>
                  <p className="text-slate-500 max-w-sm mx-auto mb-8">
                    We'll be in touch with you shortly to discuss your cleaning needs.
                  </p>
                  <button 
                    onClick={() => setStatus('idle')}
                    className="text-brand font-bold hover:text-brand-dark flex items-center gap-2"
                  >
                    Send another request <ArrowRight size={18} />
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Name</label>
                      <input
                        type="text"
                        name="name"
                        required
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:border-brand focus:ring-2 focus:ring-brand/20 outline-none transition-all font-medium text-slate-900"
                        placeholder="Your Name"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Business</label>
                      <input
                        type="text"
                        name="business"
                        value={formData.business}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:border-brand focus:ring-2 focus:ring-brand/20 outline-none transition-all font-medium text-slate-900"
                        placeholder="Company Name"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Email</label>
                      <input
                        type="email"
                        name="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:border-brand focus:ring-2 focus:ring-brand/20 outline-none transition-all font-medium text-slate-900"
                        placeholder="email@example.com"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Phone</label>
                      <input
                        type="tel"
                        name="phone"
                        required
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:border-brand focus:ring-2 focus:ring-brand/20 outline-none transition-all font-medium text-slate-900"
                        placeholder="(613) 555-0123"
                      />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Interested Services</label>
                    <div className="space-y-3">
                      {SERVICE_CATEGORIES.map((cat, idx) => (
                        <div key={idx}>
                          <h5 className="text-[10px] font-bold text-brand mb-1.5 uppercase">{cat.category}</h5>
                          <div className="flex flex-wrap gap-2">
                            {cat.items.map((service) => (
                              <button
                                type="button"
                                key={service}
                                onClick={() => toggleService(service)}
                                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${
                                  formData.services.includes(service)
                                    ? 'bg-slate-900 text-white border-slate-900'
                                    : 'bg-white text-slate-600 border-gray-200 hover:border-brand hover:text-brand'
                                }`}
                              >
                                {service}
                              </button>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Frequency</label>
                    <div className="flex flex-wrap gap-2">
                      {FREQUENCY_OPTIONS.map((freq) => (
                        <button
                          type="button"
                          key={freq}
                          onClick={() => setFrequency(freq)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${
                            formData.frequency === freq
                              ? 'bg-slate-900 text-white border-slate-900'
                              : 'bg-white text-slate-600 border-gray-200 hover:border-brand hover:text-brand'
                          }`}
                        >
                          {freq}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-wider ml-1">Message</label>
                    <textarea
                      name="message"
                      rows={3}
                      value={formData.message}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-xl bg-gray-50 border border-gray-200 focus:border-brand focus:ring-2 focus:ring-brand/20 outline-none transition-all font-medium text-slate-900 resize-none"
                      placeholder="Please tell us about your facility (Approximate sq footage, number of floors, etc.)"
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    disabled={status === 'submitting'}
                    className="w-full bg-brand hover:bg-brand-dark text-white font-black py-4 rounded-xl transition-all duration-300 shadow-lg hover:shadow-xl hover:-translate-y-1 flex items-center justify-center gap-3 uppercase tracking-wide text-sm"
                  >
                    {status === 'submitting' ? (
                      <>
                        <Loader2 className="animate-spin" size={20} />
                        Processing...
                      </>
                    ) : (
                      <>
                        Get My Free Quote <Send size={18} />
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default QuoteForm;