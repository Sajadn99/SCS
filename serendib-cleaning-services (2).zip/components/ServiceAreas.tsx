import React from 'react';
import { MapPin } from 'lucide-react';

const ServiceAreas: React.FC = () => {
  const areas = [
    "Cornwall",
    "Ottawa",
    "Brockville",
    "Hawkesbury",
    "Alexandria",
    "Lancaster",
    "Morrisburg",
    "Ingleside",
    "Casselman",
    "Winchester",
    "Kemptville",
    "Prescott",
    "Embrun",
    "Russell"
  ];

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetId = href.replace('#', '');
    const element = document.getElementById(targetId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="py-24 bg-slate-900 text-white relative overflow-hidden border-t border-white/5">
      {/* Decorative Background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-brand/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-brand font-bold tracking-widest uppercase text-xs mb-3">Service Area</h2>
          <h3 className="text-3xl md:text-4xl font-bold text-white mb-6">Proudly Serving Eastern Ontario</h3>
          <p className="text-lg text-gray-400">
            We provide reliable commercial cleaning services to businesses throughout Cornwall, Ottawa, and surrounding communities.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-3">
          {areas.map((area, idx) => (
            <div 
              key={idx}
              className="group flex items-center gap-2 bg-white/5 backdrop-blur-sm border border-white/5 px-5 py-2.5 rounded-full hover:bg-brand hover:border-brand transition-all duration-300 cursor-default"
            >
              <MapPin size={16} className="text-brand group-hover:text-white transition-colors" />
              <span className="font-medium text-gray-300 group-hover:text-white text-sm">{area}</span>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
            <p className="text-gray-500 text-sm flex items-center justify-center gap-2">
                <span className="w-2 h-2 rounded-full bg-brand animate-pulse"></span>
                Service availability may vary by specific location. 
                <a 
                  href="#contact" 
                  onClick={(e) => handleLinkClick(e, '#contact')}
                  className="text-brand hover:text-white transition-colors underline decoration-dotted underline-offset-4"
                >
                  Contact us
                </a> to check your area.
            </p>
        </div>
      </div>
    </section>
  );
};

export default ServiceAreas;