import React from 'react';
import { SERVICES_DATA } from '../constants';

const Services: React.FC = () => {
  return (
    <section id="services" className="py-24 bg-slate-50 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-3xl mx-auto mb-20">
            <span className="bg-brand/10 text-brand-dark font-bold px-4 py-1.5 rounded-full text-xs tracking-wider uppercase mb-6 inline-block">Our Expertise</span>
            
            {/* Colored Gradient Header */}
            <h2 className="text-4xl md:text-5xl font-black mb-6 leading-tight">
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-dark via-brand to-brand-light">
                Cleaning Solutions
              </span> <br className="hidden md:block" />
              <span className="text-slate-900">Tailored For You.</span>
            </h2>

            <p className="text-slate-500 text-lg leading-relaxed">
                We deliver a level of cleanliness that protects your brand and your people. Explore our comprehensive range of commercial services designed for modern businesses.
            </p>
        </div>

        <div className="space-y-24">
          {SERVICES_DATA.map((category) => (
            <div key={category.id} className="relative">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-10 border-b border-gray-200 pb-4">
                <div>
                    {/* Colored Category Header */}
                    <h3 className="text-3xl font-black text-brand-dark mb-2">{category.title}</h3>
                    <p className="text-slate-500 font-medium">{category.description}</p>
                </div>
                <div className="hidden md:block w-32 h-1 bg-gradient-to-r from-brand-dark to-brand-light rounded-full"></div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {category.items.map((service, idx) => (
                  <div 
                    key={idx} 
                    className="group bg-white p-8 rounded-2xl border border-gray-100 hover:border-brand shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-2 relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-brand/5 rounded-bl-full -mr-8 -mt-8 transition-transform group-hover:scale-150 group-hover:bg-brand/10"></div>
                    
                    <div className="relative z-10">
                        <div className="w-14 h-14 bg-slate-50 rounded-xl flex items-center justify-center mb-6 text-brand border border-gray-100 group-hover:bg-brand group-hover:text-white group-hover:rotate-6 transition-all duration-300 shadow-sm">
                           <service.icon size={28} strokeWidth={1.5} />
                        </div>
                        
                        <h4 className="text-xl font-bold text-slate-900 mb-3 group-hover:text-brand transition-colors">{service.title}</h4>
                        <p className="text-slate-500 text-sm leading-relaxed mb-4">{service.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;