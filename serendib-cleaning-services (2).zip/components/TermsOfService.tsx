import React, { useEffect } from 'react';

const TermsOfService: React.FC = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <section className="pt-32 pb-24 px-4 sm:px-6 lg:px-8 bg-slate-50 min-h-screen">
      <div className="max-w-4xl mx-auto bg-white p-8 md:p-12 rounded-3xl shadow-sm border border-gray-100">
        <h1 className="text-3xl md:text-4xl font-black text-slate-900 mb-8">Terms of Service</h1>
        
        <div className="prose prose-slate max-w-none text-slate-600">
          <p className="mb-6">Last updated: {new Date().toLocaleDateString()}</p>

          <p className="mb-6">
            Please read these Terms of Service ("Terms") carefully before using the Serendib Cleaning Services website or engaging our services. By accessing or using our services, you agree to be bound by these Terms.
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">1. Services</h2>
          <p className="mb-6">
            Serendib Cleaning Services provides commercial cleaning, janitorial services, and related property maintenance solutions. The specific scope of work, frequency, and pricing will be outlined in a separate Service Agreement or Quote provided to you.
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">2. Quotes and Estimates</h2>
          <p className="mb-6">
            Quotes provided through this website are estimates based on the information provided. Final pricing is subject to an on-site inspection and mutual agreement on the scope of work. We reserve the right to adjust pricing if the actual requirements differ significantly from the initial description.
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">3. Cancellations and Rescheduling</h2>
          <p className="mb-6">
             We understand that schedules change. We request at least 24 hours' notice for cancellation or rescheduling of one-time services. Contracted recurring services are subject to the cancellation terms outlined in your specific Service Agreement.
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">4. Intellectual Property</h2>
          <p className="mb-6">
            The content on this website, including text, graphics, logos, and images, is the property of Serendib Cleaning Services and is protected by copyright and other intellectual property laws.
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">5. Limitation of Liability</h2>
          <p className="mb-6">
            In no event shall Serendib Cleaning Services be liable for any indirect, incidental, special, or consequential damages arising out of or in connection with the use of our services or website.
          </p>

          <h2 className="text-xl font-bold text-slate-900 mt-8 mb-4">6. Governing Law</h2>
          <p className="mb-6">
            These Terms shall be governed by and construed in accordance with the laws of the Province of Ontario and the federal laws of Canada applicable therein.
          </p>
        </div>
      </div>
    </section>
  );
};

export default TermsOfService;