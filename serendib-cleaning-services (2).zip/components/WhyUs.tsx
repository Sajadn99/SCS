import React from 'react';
import { CheckCircle2, ShieldCheck, Leaf, Wallet, ListChecks, MapPin, Star } from 'lucide-react';

const WhyUs: React.FC = () => {
  return (
    <section id="why-us" className="py-24 bg-brand-black text-white relative overflow-hidden">
      {/* Decorative */}
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-brand/10 rounded-full blur-3xl translate-x-1/2 -translate-y-1/2"></div>
      <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-brand-dark/20 rounded-full blur-3xl -translate-x-1/2 translate-y-1/2"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20 max-w-3xl mx-auto">
             <span className="text-brand font-bold tracking-widest uppercase text-xs mb-3 block">Why Choose Serendib</span>
             <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
               More Than Just A <span className="text-brand">Cleaning Company.</span>
             </h2>
             <p className="text-gray-400 text-lg">
               We don't just clean spaces. We create healthier, more productive environments for your business with unmatched transparency.
             </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-24">
            {/* Reliable */}
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-8 md:p-10 rounded-3xl hover:bg-white/10 transition-colors group">
                <ShieldCheck className="text-brand mb-6 group-hover:scale-110 transition-transform" size={48} />
                <h3 className="text-2xl font-bold mb-4 text-white group-hover:text-brand-light transition-colors">Reliable</h3>
                <p className="text-gray-400 leading-relaxed">
                    We are fully bonded and insured. Every member of our team undergoes rigorous background checks and professional training to ensure your property is secure and treated with respect.
                </p>
            </div>
            
            {/* No Hidden Fees (Requested) */}
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-8 md:p-10 rounded-3xl hover:bg-white/10 transition-colors group">
                <Wallet className="text-brand mb-6 group-hover:scale-110 transition-transform" size={48} />
                <h3 className="text-2xl font-bold mb-4 text-white group-hover:text-brand-light transition-colors">No Hidden Fees</h3>
                <p className="text-gray-400 leading-relaxed">
                    We believe in complete transparency. Our quotes are comprehensive with <strong>absolutely no hidden charges</strong> for standard equipment or supplies. The price we quote is the price you pay—guaranteed.
                </p>
            </div>

            {/* Quality Control */}
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-8 md:p-10 rounded-3xl hover:bg-white/10 transition-colors group">
                <ListChecks className="text-brand mb-6 group-hover:scale-110 transition-transform" size={48} />
                <h3 className="text-2xl font-bold mb-4 text-white group-hover:text-brand-light transition-colors">Proactive Quality Control</h3>
                <p className="text-gray-400 leading-relaxed">
                    We don't wait for complaints. Our supervisors perform regular, unannounced 50-point inspections before handover to ensure our high standards are consistently met.
                </p>
            </div>

            {/* Eco Friendly */}
            <div className="bg-white/5 backdrop-blur-sm border border-white/10 p-8 md:p-10 rounded-3xl hover:bg-white/10 transition-colors group">
                <Leaf className="text-brand mb-6 group-hover:scale-110 transition-transform" size={48} />
                <h3 className="text-2xl font-bold mb-4 text-white group-hover:text-brand-light transition-colors">Eco-Friendly First</h3>
                <p className="text-gray-400 leading-relaxed">
                    We exclusively use Green Seal certified products and HEPA filtration technology. Powerful on dirt, but safe for your employees, clients, and the planet.
                </p>
            </div>
        </div>

        {/* The Serendib Standard - Enhanced & Cleaned */}
        <div className="bg-gradient-to-br from-brand-dark to-brand-black rounded-3xl p-8 md:p-16 border border-brand/20 shadow-2xl relative overflow-hidden text-center">
            <div className="absolute top-0 right-0 w-96 h-96 bg-brand/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
            <div className="absolute bottom-0 left-0 w-96 h-96 bg-brand/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>
            
            <div className="relative z-10 max-w-4xl mx-auto">
                <div className="inline-flex items-center gap-2 bg-brand/20 text-brand-light px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider mb-8">
                    <Star size={14} className="fill-brand-light" />
                    The Serendib Standard
                </div>
                
                <h3 className="text-3xl md:text-5xl font-black text-white mb-8 leading-tight">
                    Cleaning That Exceeds<br/>Expectations.
                </h3>
                <p className="text-gray-300 mb-12 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed">
                   While others cut corners, we clean them. Experience the difference of a cleaning partner that treats your facility like their own.
                </p>
                
                <div className="grid md:grid-cols-2 gap-4 text-left">
                    <div className="bg-white/5 p-6 rounded-2xl flex items-center gap-5 border border-white/5 hover:border-brand/30 transition-colors">
                        <div className="w-12 h-12 rounded-full bg-brand/20 flex items-center justify-center shrink-0">
                           <CheckCircle2 className="text-brand" size={24} />
                        </div>
                        <div>
                            <h4 className="font-bold text-white">Dedicated Account Manager</h4>
                            <p className="text-sm text-gray-400">Single point of contact for your peace of mind.</p>
                        </div>
                    </div>
                    
                    <div className="bg-white/5 p-6 rounded-2xl flex items-center gap-5 border border-white/5 hover:border-brand/30 transition-colors">
                        <div className="w-12 h-12 rounded-full bg-brand/20 flex items-center justify-center shrink-0">
                           <ListChecks className="text-brand" size={24} />
                        </div>
                        <div>
                            <h4 className="font-bold text-white">Customized Protocols</h4>
                            <p className="text-sm text-gray-400">Tailored cleaning checklists for every space.</p>
                        </div>
                    </div>

                    <div className="bg-white/5 p-6 rounded-2xl flex items-center gap-5 border border-white/5 hover:border-brand/30 transition-colors">
                        <div className="w-12 h-12 rounded-full bg-brand/20 flex items-center justify-center shrink-0">
                           <Clock className="text-brand" size={24} />
                        </div>
                        <div>
                            <h4 className="font-bold text-white">24/7 Response</h4>
                            <p className="text-sm text-gray-400">Ready for emergencies whenever you need us.</p>
                        </div>
                    </div>

                    <div className="bg-white/5 p-6 rounded-2xl flex items-center gap-5 border border-white/5 hover:border-brand/30 transition-colors">
                        <div className="w-12 h-12 rounded-full bg-brand/20 flex items-center justify-center shrink-0">
                           <MapPin className="text-brand" size={24} />
                        </div>
                        <div>
                            <h4 className="font-bold text-white">We Come To You</h4>
                            <p className="text-sm text-gray-400">You don't come to us. We bring professional care to you.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

      </div>
    </section>
  );
};

// Helper component for the icon used in the grid
function Clock({ className, size }: { className?: string, size?: number }) {
    return (
        <svg 
            xmlns="http://www.w3.org/2000/svg" 
            width={size} 
            height={size} 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            className={className}
        >
            <circle cx="12" cy="12" r="10"/>
            <polyline points="12 6 12 12 16 14"/>
        </svg>
    )
}

export default WhyUs;