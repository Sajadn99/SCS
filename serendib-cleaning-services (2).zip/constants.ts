import { 
  Sparkles, 
  Wind, 
  Droplets, 
  Layers, 
  Hammer, 
  Zap, 
  Footprints,
  Brush,
  ShieldPlus,
  Armchair,
  Grid,
  HardHat,
  PaintBucket,
  Eraser,
  Umbrella,
  ShowerHead
} from 'lucide-react';
import { ServiceCategory } from './types';

export const CONTACT_INFO = {
  phone: "613-861-5196",
  email: "contact@serendibcleaningservices.ca",
  address: "3205 Vincent Massey Drive, Long Sault, K0C 1P0",
  mapsLink: "https://www.google.com/maps/search/?api=1&query=3205+Vincent+Massey+Drive+Long+Sault+ON"
};

export const SERVICES_DATA: ServiceCategory[] = [
  {
    id: "interior",
    title: "Interior Cleaning",
    description: "Reliable solutions for hygienic and professional indoor environments.",
    items: [
      { title: "Janitorial Services", description: "Scheduled daily or weekly maintenance for professional workspaces.", icon: Sparkles },
      { title: "Carpet Cleaning", description: "Deep extraction to remove allergens, stains, and dirt.", icon: Layers },
      { title: "Window Cleaning", description: "Streak-free interior and exterior window washing.", icon: Droplets },
      { title: "High & Low Dusting", description: "Detailed removal of dust from vents, ceilings, and baseboards.", icon: Wind },
      { title: "Pedisystems", description: "Specialized maintenance for high-traffic entrance matting.", icon: Footprints },
      { title: "Upholstery Cleaning", description: "Revitalizing office chairs, sofas, and fabric partitions.", icon: Armchair },
      { title: "Sanitization Services", description: "Hospital-grade disinfection for high-touch surfaces.", icon: ShieldPlus },
      { title: "Restroom Deep Clean", description: "Intensive descaling and sanitization for washrooms.", icon: ShowerHead },
    ]
  },
  {
    id: "floor",
    title: "Floor Care",
    description: "Protect and extend the life of your flooring investment.",
    items: [
      { title: "Strip & Wax", description: "Complete stripping and waxing to restore shine and durability.", icon: Brush },
      { title: "Tile & Grout Scrub", description: "Machine scrubbing to remove embedded dirt from grout lines.", icon: Grid },
      { title: "Buffing & Polishing", description: "High-speed burnishing to maintain a glossy finish.", icon: Sparkles },
    ]
  },
  {
    id: "construction",
    title: "Construction Cleaning",
    description: "Getting your new space ready for business.",
    items: [
      { title: "Rough Cleaning", description: "Removal of heavy debris, stickers, and construction residue.", icon: HardHat },
      { title: "Post-Construction", description: "Detailed cleaning of all surfaces after renovations.", icon: Hammer },
      { title: "Final Detail Clean", description: "White-glove inspection cleaning before occupancy.", icon: PaintBucket },
    ]
  },
  {
    id: "exterior",
    title: "Exterior Cleaning",
    description: "Enhance your property's curb appeal and safety.",
    items: [
      { title: "Power Washing", description: "High-pressure cleaning for sidewalks, parking lots, and facades.", icon: Zap },
      { title: "Gutter Cleaning", description: "Removal of debris to ensure proper drainage.", icon: Umbrella },
      { title: "Graffiti Removal", description: "Safe and effective removal of spray paint and markings.", icon: Eraser },
    ]
  }
];