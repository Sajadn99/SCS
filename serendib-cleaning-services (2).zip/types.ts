import { LucideIcon } from 'lucide-react';

export type View = 'home' | 'privacy' | 'terms';

export interface ServiceItem {
  title: string;
  description: string;
  icon: LucideIcon;
}

export interface ServiceCategory {
  id: string;
  title: string;
  description: string;
  items: ServiceItem[];
}

export interface QuoteFormData {
  name: string;
  business: string;
  email: string;
  phone: string;
  services: string[];
  frequency: string;
  message: string;
}